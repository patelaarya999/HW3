// Load CSV data locally
d3.csv("http://localhost:8000/iris.csv").then(function(data) {
    // Convert string values to numbers
    data.forEach(function(d) {
        d.PetalLength = +d.PetalLength;
        d.PetalWidth = +d.PetalWidth;
    });

    // --- Scatter Plot ---
    // Define dimensions and margins for the scatter plot
    const margin = { top: 20, right: 30, bottom: 30, left: 40 };
    const width = 500 - margin.left - margin.right;
    const height = 400 - margin.top - margin.bottom;

    // Create the SVG container for the scatter plot
    const svgScatter = d3.select("#scatterplot")
        .append("svg")
        .attr("width", width + margin.left + margin.right)
        .attr("height", height + margin.top + margin.bottom)
        .append("g")
        .attr("transform", `translate(${margin.left},${margin.top})`);

    // Set up scales for x and y axes
    const xScale = d3.scaleLinear()
        .domain([d3.min(data, d => d.PetalLength) - 1, d3.max(data, d => d.PetalLength) + 1])
        .range([0, width]);

    const yScale = d3.scaleLinear()
        .domain([d3.min(data, d => d.PetalWidth) - 1, d3.max(data, d => d.PetalWidth) + 1])
        .range([height, 0]);

    const colorScale = d3.scaleOrdinal(d3.schemeCategory10)
        .domain(data.map(d => d.Species));

    // Add circles for each data point
    svgScatter.selectAll("circle")
        .data(data)
        .enter()
        .append("circle")
        .attr("cx", d => xScale(d.PetalLength))
        .attr("cy", d => yScale(d.PetalWidth))
        .attr("r", 5)
        .attr("fill", d => colorScale(d.Species));

    // Add x-axis and y-axis
    svgScatter.append("g")
        .attr("transform", `translate(0,${height})`)
        .call(d3.axisBottom(xScale));
    
    svgScatter.append("g")
        .call(d3.axisLeft(yScale));

    // Add x-axis label with extra space for scatter plot
    svgScatter.append("text")
        .attr("transform", `translate(${width / 2},${height + margin.bottom + 0.1})`)
        .style("text-anchor", "middle")
        .text("Petal Length");

    // Add y-axis label for scatter plot
    svgScatter.append("text")
        .attr("transform", "rotate(-90)")
        .attr("y", 0 - margin.left + 15)
        .attr("x", 0 - (height / 2))
        .style("text-anchor", "middle")
        .text("Petal Width");

    // Add legend
    const legend = svgScatter.selectAll(".legend")
        .data(colorScale.domain())
        .enter().append("g")
        .attr("class", "legend")
        .attr("transform", (d, i) => `translate(0,${i * 20})`);

    legend.append("rect")
        .attr("x", width - 18)
        .attr("width", 18)
        .attr("height", 18)
        .style("fill", colorScale);

    legend.append("text")
        .attr("x", width - 24)
        .attr("y", 9)
        .attr("dy", ".35em")
        .style("text-anchor", "end")
        .text(d => d);

    // --- Box Plot ---
    // Set up the SVG for the box plot
    const svgBox = d3.select("#boxplot")
        .append("svg")
        .attr("width", width + margin.left + margin.right)
        .attr("height", height + margin.top + margin.bottom)
        .append("g")
        .attr("transform", `translate(${margin.left},${margin.top})`);

    // Calculate quartiles and draw box plots
    const rollupFunction = function(groupData) {
        const values = groupData.map(d => d.PetalLength).sort(d3.ascending);
        const q1 = d3.quantile(values, 0.25);
        const median = d3.quantile(values, 0.5);
        const q3 = d3.quantile(values, 0.75);
        const iqr = q3 - q1;
        const min = d3.min(values);
        const max = d3.max(values);
        return { q1, median, q3, iqr, min, max };
    };

    const quartilesBySpecies = d3.rollup(data, rollupFunction, d => d.Species);

    const xScaleBox = d3.scaleBand()
        .domain(quartilesBySpecies.keys())
        .range([0, width])
        .padding(0.1);

    const yScaleBox = d3.scaleLinear()
        .domain([0, d3.max(Array.from(quartilesBySpecies.values()), d => d.q3 + 1)])
        .range([height, 0]);

    svgBox.append("g")
        .attr("transform", `translate(0,${height})`)
        .call(d3.axisBottom(xScaleBox));

    svgBox.append("g")
        .call(d3.axisLeft(yScaleBox));

    quartilesBySpecies.forEach((quartiles, species) => {
        const x = xScaleBox(species);
        const boxWidth = xScaleBox.bandwidth();

        // Draw vertical lines for whiskers
        svgBox.append("line")
            .attr("x1", x + boxWidth / 2)
            .attr("x2", x + boxWidth / 2)
            .attr("y1", yScaleBox(quartiles.q1 - 1.5 * quartiles.iqr))
            .attr("y2", yScaleBox(quartiles.q3 + 1.5 * quartiles.iqr))
            .attr("stroke", "black");

        // Draw box
        svgBox.append("rect")
            .attr("x", x)
            .attr("y", yScaleBox(quartiles.q3))
            .attr("width", boxWidth)
            .attr("height", yScaleBox(quartiles.q1) - yScaleBox(quartiles.q3))
            .attr("fill", "lightgray");

        // Draw median line
        svgBox.append("line")
            .attr("x1", x)
            .attr("x2", x + boxWidth)
            .attr("y1", yScaleBox(quartiles.median))
            .attr("y2", yScaleBox(quartiles.median))
            .attr("stroke", "red")
            .attr("stroke-width", 2);
    });

    // Add x-axis label with extra space for box plot
    svgBox.append("text")
        .attr("transform", `translate(${width / 2},${height + margin.bottom + 0.1})`)
        .style("text-anchor", "middle")
        .text("Species");

    // Add y-axis label for box plot
    svgBox.append("text")
        .attr("transform", "rotate(-90)")
        .attr("y", 0 - margin.left + 15)
        .attr("x", 0 - (height / 2))
        .style("text-anchor", "middle")
        .text("Petal Length");
});